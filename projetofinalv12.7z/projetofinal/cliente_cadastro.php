<?php
require_once("banco_dados/gerente_cliente.php");
require_once("banco_dados/gerente_banco.php");
require_once("cabecalho2.php");


$cliente=buscarUsuario($email, $senha, $conexao);
$cliente_id=$cliente["idUsuario"];


?>

				<section id="cadastrarCliente">
        		<div class="container">
				<form action="gerente_cadastra.php" method="post">                   
                    <tr>
                        <td>Id</td>
                        <td><input class="form-control" type="text" name="cliente_id" 
                            value="<?=$cliente_id?>" readonly></td>
                    </tr>
                    <tr>
                        <td>Nome do cliente</td>
                        <td><input class="form-control" type="text" name="nomeCliente" value=""></td>
                    </tr>  

                    <tr>
                        <td>Limite do cliente</td>
                        <td><input class="form-control" type="number" name="limiteCliente" value="" ></td>
                    </tr> 

                    <tr>
                        <td>Saldo do cliente</td>
                        <td><input class="form-control" type="number" name="saldoCliente" value="" ></td>
                    </tr>
                    

                    <td>Tipo do Conta</td>
                    <td>
                        <select name="tipoConta" class="form-control">
                            <option value="corrente">Corrente</option>
                            <option value="poupanca">Poupança</option>
                        </select>

                    </td>
                    <tr>
                        <td><button class="btn btn-primary" type="submit">Cadastrar</button></td>
                        
                    </tr>
                </table>
            </form>
        </div>
    </section>


<?php
require_once("rodape.php");

?>
    