<?php
require_once("cabecalho2.php");
require_once("class/Conta.php");
require_once("banco_dados/gerente_cliente.php");
require_once("banco_dados/gerente_banco.php");

$numeroConta=$_POST['numero'];
$contaDestino=$_POST['contaDestino'];
$valor=$_POST['transferir'];
$data=  date("Y-m-d");


$Cliente= buscarCliente($conexao, $numeroConta);
$Cliente->transferir($valor);
$Cliente2= buscarCliente($conexao, $contaDestino);
$Cliente2->Depositar($valor);

if($Cliente->getSaldo() >= $valor and $Cliente2->getLimite() > $valor and $Cliente2->getLimite() >= $Cliente2->getSaldo() and atualizarSaldo($Cliente,$conexao) and atualizarSaldo($Cliente2,$conexao) and insereTransferencia($data,$numeroConta, $conexao)){ ?>

<div class="container">
	<h2> Tranferência realizada com sucesso !</h2>
	<h3>Novo saldo da conta: <?=$Cliente->getSaldo()?> </h3>
	<a href="cliente_index.php#transferencia" class="btn btn-primary" >Transferir novamente</a>
	<a href="cliente_index.php#extrato" class="btn btn-primary" >Veja seu extrato</a>
	<a href="cliente_index.php" class="btn btn-primary" >Página Inicial</a>
</div>

<?php
}else{

	$msg= mysqli_error($conexao);?>
	<div class="container">
	<p class="bg-danger">
	Erro na transferencia <?=$msg?></p>
	<a href="cliente_index.php#transferencia" class="btn btn-primary" >Tente novamente</a>
	</div>
<?php
}
require_once("rodape.php");
?>
