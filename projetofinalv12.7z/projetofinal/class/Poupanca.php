<?php

	//A classe Ebook herda os atributos e métodos da classe Livro
	class ContaPoupanca extends Conta{
		
		public function atualizar($taxa=0.5){
				//retorna 5% do valor da Conta
				$this->saldo+= $this->saldo * $taxa * 3;
			}

	
	}