<?php
require_once("cabecalho.php");
require_once("banco-livro.php");
require_once("class/Livro.php");
require_once("class/Ebook.php");
require_once("class/LivroFisico.php");
require_once("class/Categorias.php");



//armazenando os valores do formulário no objeto Livro
$Nome=$_POST['nomeCliente'];
$Saldo=$_POST['saldoCliente'];
$Limite=$_POST['limiteCliente'];

/*criando um objeto "categoria" para armazenar
dentro do objeto "livro"*/
//$categoria= new Categorias();
//$categoria->setId($_POST['categoria_id']); 

if($tipoConta=="corrente"){
$Livro= new Corrente($Nome, $Saldo, $Limite, $tipoConta);
}else{
$Livro= new Poupanca($Nome, $Saldo, $Limite, $tipoConta);
}


if(insereCliente($Cliente, $conexao)){ ?>

<p class="bg-success">
	O livro <?=$Cliente?> foi cadastrado!</p>
<?php
}else{
	$msg= mysqli_error($conexao);?>
	<p class="bg-danger">
	O livro <?=$Cliente?> não foi cadastrado: <?=$msg?></p>
<?php
}
?>