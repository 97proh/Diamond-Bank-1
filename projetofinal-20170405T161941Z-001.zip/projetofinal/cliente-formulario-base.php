<tr>
 			<td>Nome</td>
 			<td><input class="form-control" type="text" name="nomeCliente" value="<?=$Cliente->getNome()?>" required></td>
 		</tr>	

 		<tr>
 			<td>Saldo</td>
 			<td><input class="form-control" type="number" name="saldoCliente" value="<?=$Cliente->getSaldo()?>" ></td>
 		</tr>
 		<tr>
 			<td>Limite</td>
 			<td><textarea class="form-control" name="limiteCliente"><?=$Livro->getLimiteCliente()?></textarea></td>
 		</tr>
 		
 		<tr>
 			<td>Tipo da Conta</td>
 			<td>
 				<select name="tipoConta" class="form-control" >
 					<option value="corrente">Conta Corrente</option>
 					<option value="poupanca">Conta Poupança</option>
 				</select>
 			</td>
 		</tr>
 		