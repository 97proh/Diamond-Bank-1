<?php
session_start();

//exibe a mensagem caso o usuário já esteja logado no site
function usuarioEstaLogado(){
	return isset($_SESSION ["usuario_logado"]);
}

//Verifica se o usuário esta logado e tem acesso a funcionalidade
function verificaUsuario (){
	if(!usuarioEstaLogado()){
		$_SESSION["danger"]="Você não tem acesso a 
		esta funcionalidade";
		header("Location: formulario-login.php ");
		die();
	}
}

//exibe mensagem após o login
function usuarioLogado(){
	return $_SESSION["usuario_logado"];
}

//exibe qual o usuário que está logado
function logaUsuario ($email){
	$_SESSION ["usuario_logado"]=$email;
}

//encerra a sessão atual e habilita uma nova
function logout(){
	session_destroy();
	session_start();
}

