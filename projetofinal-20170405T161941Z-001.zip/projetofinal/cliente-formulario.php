<?php
require_once("cabecalho.php");
require_once ("banco-categoria.php");
require_once ("logica-usuario.php");
require_once ("class/Categorias.php");
require_once ("class/Livro.php");

verificaUsuario();

$categoria=new Categorias();
$categoria->setId(1);

//Iniciando um objeto livro com os campos 'em branco' para o formulário de cadastro
$Cliente= new Livro("","","","",$categoria,"");
$Cliente->setCategoria($categoria);

$vetor_categorias= listarCategorias($conexao);

?>

<h1>Formulário de cadastro</h1>
<form action="cadastrarCliente.php" method="post">
 	<table class="table">
 		<?php include("cliente-formulario-base.php");?>
 		<tr>
 			<td><button class="btn btn-primary" type="submit">Cadastrar</button></td>
 			
 		</tr>
 	</table>
</form>

<?php
include("rodape.php");
?>