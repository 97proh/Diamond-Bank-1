<?php
require_once("banco_dados/conexao.php");

function buscarGerente($emailGerente, $senhaGerente, $conexao){
	//tratando os caracteres especiais do email
	$query= "select * from gerente where emailGerente='{$emailGerente}'
	and senhaGerente= '{$senhaGerente}'";
	$resultado= mysqli_query($conexao, $query);
	$gerente= mysqli_fetch_assoc($resultado);

	return $gerente; 
}

function insereCliente($email, $senha,$conexao){
	$senha= md5($senha);
	$query="insert into usuarios (email,senha)
			values ('{$email}', '{$senha}')";
	return mysqli_query($conexao,$query);
}

?>