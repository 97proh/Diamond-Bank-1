<?php
require_once("cabecalho2.php");
require_once("banco_dados/gerente_cliente.php");
require_once("class/Conta.php");
require_once("class/Corrente.php");
require_once("class/Poupanca.php");



//armazenando os valores do formulário no objeto Cliente
$nome=$_POST['nomeCliente'];
$saldo=$_POST['saldoCliente'];
$limite=$_POST['limiteCliente'];
$tipoConta= $_POST['tipoConta'];
 


if($tipoConta == "corrente"){
	$Cliente= new ContaCorrente($nome, $saldo, $limite, $tipoConta);
	
}else{
	$Cliente= new ContaPoupanca($nome, $saldo, $limite, $tipoConta);
		
}

if(insereCliente($Cliente, $conexao)){ ?>

<div class="container">
	<h2> Cliente <?=$Cliente?> foi cadastrado!</h2><br><br>
	<a href="gerente_index.php#cadastrarCliente" class="btn btn-primary" >Cadastrar novo cliente</a>
	<a href="gerente_index.php#listarCliente" class="btn btn-primary" >Ir para lista de cliente</a>
	<a href="gerente_index.php" class="btn btn-primary" >Página Inicial</a>
</div>
<?php
}else{
	$msg= mysqli_error($conexao);?>
	<p class="bg-danger">
	O Cliente  não foi cadastrado: <?=$msg?></p>
<?php
}
?>