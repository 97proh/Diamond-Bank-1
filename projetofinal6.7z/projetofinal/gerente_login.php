<?php
require_once ("cabecalho2.php");


?>



	<form action="login.php" method="post" class="container">
		<h2>Login do gerente</h2>
		<table class="table">
			<tr>
				<td>Email</td>
				<td><input type="email" class="form-control" name="email"></td>
			</tr>
			<tr>
				<td>Senha</td>
				<td><input type="password" class="form-control" name="senha"></td>
			</tr>	
			<tr>
				<td><button class="btn btn-primary">Login</button>
					
				</td>
			</tr>
		</table>

	</form>


	
<?php

require_once("rodape.php");
?>
