<?php

	//A classe Ebook herda os atributos e métodos da classe Livro
	class ContaCorrente extends Conta{
		

			public function atualizar($taxa=0.5){
				//retorna 5% do valor da Conta
				$this->saldo+= $this->saldo * $taxa * 2;
			}

			public function creditar($creditar){
				// Calcula o desconto e subtrai do preco
				$this->saldo -= $this->saldo + $creditar;
				return $this->saldo;
	}

			
	
	}