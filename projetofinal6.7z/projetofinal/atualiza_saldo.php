<?php
require_once("cabecalho2.php");
require_once("banco_dados/gerente_cliente.php");
require_once("class/Conta.php");
require_once("class/Corrente.php");
require_once("class/Poupanca.php");

$vetor_cliente=listarCliente($conexao);
 foreach ($vetor_cliente as $Cliente) {
	$Cliente->atualizar();
	$Cliente->atualizarSaldo($conexao);
	//echo $Cliente->getSaldo();
}
header("Location:gerente_index.php#listarCliente");

	


?>