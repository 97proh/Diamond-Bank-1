<?php
require_once("banco_dados/gerente_cliente.php");
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    

    <title>Diamond Bank</title>

    
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet">

    
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

    
    <link href="css/style.css" rel="stylesheet">

    
</head>

<body id="page-top" class="index">

    <nav id="mainNav" class="navbar navbar-default navbar-custom navbar-fixed-top">
        <div class="container">
            
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top">Diamond Bank</a>
            </div>

            
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#cadastrarCliente">Cadastrar Clientes</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#listarCliente">Listar Clientes</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="logout.php">Sair</a>
                    </li>
                    
                </ul>
            </div>
            
        </div>
        
    </nav>

   
    <header>
        <div class="container">
            <div class="intro-text">
                <div class="intro-lead-in">Você está logado como Gerente!</div>
                <div class="intro-heading">Cadastre novos clientes agora mesmo.</div>
                <a href="#cadastrarCliente" class="page-scroll btn btn-xl">Cadastrar clientes</a>
            </div>
        </div>
    </header>
   
   

    <!-- NESTA SEÇÃO O GERENTE VAI CADASTRAR OS CLIENTES-->
    <section id="cadastrarCliente">
        <div class="container">
           
            <form action="gerente_cadastra.php" method="post">
            <h1>Cadastro de Cliente</h1>

                <table class="table">                    
                    <tr>
                        <td>Nome do cliente</td>
                        <td><input class="form-control" type="text" name="nomeCliente" value=""></td>
                    </tr>   

                    <tr>
                        <td>Saldo do cliente</td>
                        <td><input class="form-control" type="number" name="saldoCliente" value="" ></td>
                    </tr>
                    <tr>
                        <td>Limite do cliente</td>
                        <td><input class="form-control" type="number" name="limiteCliente" value="" ></td>
                    </tr>

                    <td>Tipo do Conta</td>
                    <td>
                        <select name="tipoConta" class="form-control">
                            <option value="corrente">Corrente</option>
                            <option value="poupanca">Poupança</option>
                        </select>

                    </td>
                    <tr>
                        <td><button class="btn btn-primary" type="submit">Cadastrar</button></td>
                        
                    </tr>
                </table>
            </form>
        </div>
    </section>



    <section id="listarCliente">
        <div class="container">
           <h2>Lista de Clientes</h2>
                     
          
            <table class="table">
                <tr>
                        <th>Número da Conta</th>
                        <th>Nome</th>
                        <th>Saldo</th>
                        <th>Limite</th>
                        <th>Tipo de Conta</th>
                        <th>Alterar</th>
                        <th>Excluir</th>
                </tr>
                <?php
                $vetor_cliente=listarCliente($conexao);
                foreach ($vetor_cliente as $Cliente) {
                ?>
                    
                <tr>
                        <td><?=$Cliente->getNumero()?></td>
                        <td><?=$Cliente->getNome()?></td>
                        <td><?=$Cliente->getSaldo()?></td>
                        <td><?=$Cliente->getLimite()?></td>
                        <td><?=$Cliente->getTipoConta()?></td>
                        
                        <td>
                            <form action="cliente_formularioAltera.php" method="get">
                                <input type="hidden" name="numero" value="<?=$Cliente->getNumero()?>">
                                <button class="btn btn-primary">Alterar</button>
                            </form>
                        </td>
                        <td>
                            <form action="cliente_remove.php" method="post">
                                <input type="hidden" name="numero" value="<?=$Cliente->getNumero()?>">
                                <button class="btn btn-primary">Remover</button>
                            </form>
                        </td>
                </tr>   
            <?php
                }
            ?>
            </table>
             <form action="atualiza_saldo.php" method="get">
                 <input type="hidden" name="tipoConta" value="<?=$Cliente->getTipoConta()?>">
                 <button class="btn btn-primary">Atualizar</button>
            </form>
        </div>
    </section>
    

    
    

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <span class="copyright">Todos os direitos reservados &copy; Diamond Bank 2017</span>
                </div>
                <div class="col-md-4">
                    <ul class="list-inline social-buttons">
                        <li><a href="https://twitter.com/DiammondBank" target="_blank"><i class="fa fa-twitter"></i></a>
                        </li>
                        <li><a href="https://www.facebook.com/diammondbank/" target="_blank"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li><a href="https://www.linkedin.com/in/diamond-bank-1a0a22140/" target="_blank"><i class="fa fa-linkedin"></i></a>
                        </li>
                    </ul>
                </div>
                
            </div>
        </div>
    </footer>

       

    
    <script src="jquery/jquery.js"></script>

    
    <script src="bootstrap/js/bootstrap.js"></script>

   
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js" integrity="sha384-mE6eXfrb8jxl0rzJDBRanYqgBxtJ6Unn4/1F7q4xRRyIw7Vdg9jP4ycT7x1iVsgb" crossorigin="anonymous"></script>

    
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    
    <script src="js/agency.js"></script>

</body>

</html>
