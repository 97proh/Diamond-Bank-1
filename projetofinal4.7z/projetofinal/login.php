<?php
require_once("/banco_dados/banco-cliente.php");
require_once("logica-usuario.php");

$email= $_POST['email'];
$senha= $_POST['senha'];
$usuario=buscarUsuario($email, $senha, $conexao);

if($usuario == null){ 
	$_SESSION["danger"]="Usuario ou senha inválido!";
	header("Location:cliente_login.php");
}else{ 
	
	header("Location:cliente_index.php");
}
die();