<?php
require_once("conecta.php");

function buscarCliente($email, $senha, $conexao){
	//tratando os caracteres especiais do email
	$emailT= mysqli_real_escape_string($conexao,$email);
	$senha= md5($senha);
	$query= "select * from usuarios where email='{$emailT}'
	and senha= '{$senha}'";
	$resultado= mysqli_query($conexao, $query);
	$usuario= mysqli_fetch_assoc($resultado);

	return $usuario; 
}

function insereCliente($email, $senha,$conexao){
	$senha= md5($senha);
	$query="insert into usuarios (email,senha)
			values ('{$email}', '{$senha}')";
	return mysqli_query($conexao,$query);
}