<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <span class="copyright">Todos os direitos reservados &copy; Diamond Bank 2017</span>
                </div>
                <div class="col-md-4">
                    <ul class="list-inline social-buttons">
                        <li><a href="https://twitter.com/DiammondBank" target="_blank"><i class="fa fa-twitter"></i></a>
                        </li>
                        <li><a href="https://www.facebook.com/diammondbank/" target="_blank"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li><a href="https://www.linkedin.com/in/diamond-bank-1a0a22140/" target="_blank"><i class="fa fa-linkedin"></i></a>
                        </li>
                    </ul>
                </div>
                
            </div>
        </div>
    </footer>

       

    
    <script src="jquery/jquery.js"></script>

    
    <script src="bootstrap/js/bootstrap.js"></script>

   
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js" integrity="sha384-mE6eXfrb8jxl0rzJDBRanYqgBxtJ6Unn4/1F7q4xRRyIw7Vdg9jP4ycT7x1iVsgb" crossorigin="anonymous"></script>

    
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    
    <script src="js/agency.js"></script>

</body>

</html>