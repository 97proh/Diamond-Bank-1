<?php
require_once("cabecalho2.php");
require_once("banco_dados/gerente_banco.php");
require_once("banco_dados/gerente_cliente.php");
require_once("class/Conta.php");
require_once("class/Poupanca.php");
require_once("class/Corrente.php");


$numero = $_GET['numero'];
$Cliente= buscarCliente($conexao, $numero);


?>

    <div class="container">
           
     
    <input type= "hidden" name="numero" value=<?=$Cliente->getUsuario_Id()?>>
	<input type= "hidden" name="numero" value=<?=$Cliente->getNumero()?>>
 	<form action="cliente_alterar.php" method="post">
            <h1>Alterar Cadastro</h1>
                <table class="table">  
                    <tr>
                        
                        <input class="form-control" type="hidden" name="cliente_id" 
                            value="<?=$cliente_id?>" readonly>
                    </tr>                  
                    <tr>
                        <td>Número da conta</td>
                        <td><input class="form-control" type="text" name="numeroConta" 
                        	value="<?=$Cliente->getNumero()?>" readonly></td>
                    </tr>
                    <tr>
                        <td>Nome do cliente</td>
                        <td><input class="form-control" type="text" name="nomeCliente" 
                        	value="<?=$Cliente->getNome()?>"></td>
                    </tr>   

                    <tr>
                        <td>Saldo do cliente</td>
                        <td><input class="form-control" type="number" name="saldoConta" 
                        	value="<?=$Cliente->getSaldo()?>" ></td>
                    </tr>
                    <tr>
                        <td>Limite do cliente</td>
                        <td><input class="form-control" type="number" name="limiteConta" 
                        	value="<?=$Cliente->getLimite()?>" ></td>
                    </tr>

                    <td>Tipo de Conta (Conta atual:<?=$Cliente->getTipoConta()?>)</td>

                    <td>
                        <select name="tipoConta" class="form-control">
                            <option value="corrente">Corrente</option>
                            <option value="poupanca">Poupança</option>
                        </select>

                    </td>
                    <tr>
                        <td><button class="btn btn-primary" type="submit">Alterar</button></td>
                        
                    </tr>
                </table>
            </form>


   </div>

<?php
require_once("rodape.php");
?>