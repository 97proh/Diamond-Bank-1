<?php
require_once("banco_dados/conexao.php");
require_once("class/Conta.php");
require_once("class/Corrente.php");
require_once("class/Poupanca.php");
require_once("logica-usuario.php");

function mostraUsuario($conexao){
	$email=usuarioLogado();
	$query="select nomeCliente, numeroConta FROM conta join usuario 
	on usuario.idUsuario= conta.usuario_idUsuario
	where usuario.email= '{$email}'";
	$resultado= mysqli_query($conexao, $query);
	$usuario=mysqli_fetch_assoc($resultado);
	return $usuario;
}


function insereCliente(Conta $Cliente, $conexao){
	
	$query= "insert into conta (saldoConta, tipoConta, limiteConta, nomeCliente, usuario_idUsuario)
			values ({$Cliente->getSaldo()}, '{$Cliente->getTipoConta()}', {$Cliente->getlimite()},
			 '{$Cliente->getNome()}', {$Cliente->getUsuario_id()})";
				//echo $query;
	return mysqli_query($conexao, $query);
}

function insereSaque($data,$numeroConta, $conexao){
	
	$query="insert into extrato (operacao,data, numero_id)
			values ('Saque', '{$data}','{$numeroConta}')";
	return mysqli_query($conexao,$query);
}
function insereDeposito($data,$numeroConta, $conexao){
	
	$query="insert into extrato (operacao,data, numero_id)
			values ('Depósito', '{$data}','{$numeroConta}')";
	return mysqli_query($conexao,$query);
}
function insereTransferencia($data,$numeroConta, $conexao){
	
	$query="insert into extrato (operacao,data, numero_id)
			values ('Transferencia', '{$data}','{$numeroConta}')";
	return mysqli_query($conexao,$query);
}
function atualizarSaldo($Cliente, $conexao){

	$query = "update conta set saldoConta = '{$Cliente->getSaldo()}'
		where numeroConta = {$Cliente->getNumero()}";

	return mysqli_query($conexao, $query);

}

function listarCliente ($conexao){
	$vetor_cliente= array();
	$query="select * from conta";
	$resultado= mysqli_query($conexao, $query);
	while ($cliente_array= mysqli_fetch_assoc($resultado)){
		/* criando um objeto cliente a cada repetição
		 do laço*/
		 
		 $numero=$cliente_array['numeroConta'];
		 $nome=$cliente_array['nomeCliente'];
		 $saldo=$cliente_array['saldoConta'];
		 $limite= $cliente_array['limiteConta'];
		 $tipoConta= $cliente_array['tipoConta'];	
		 $usuario_id= $cliente_array['usuario_idUsuario'];	
		 if($tipoConta == "corrente"){
			$Cliente= new ContaCorrente($nome, $saldo, $limite, $tipoConta,$usuario_id);
			
		}else{
			$Cliente= new ContaPoupanca($nome, $saldo, $limite, $tipoConta,$usuario_id);
				
		}
		
		 $Cliente->setNumero($numero);
		 array_push($vetor_cliente, $Cliente);
	}
	return $vetor_cliente;
}
function mostraExtrato($conexao){
	$vetor_extrato= array();
	$query="select operacao, data FROM extrato";
	$resultado= mysqli_query($conexao, $query);
	while ($extrato= mysqli_fetch_assoc($resultado)){
		/* criando um objeto cliente a cada repetição
		 do laço*/
				 array_push($vetor_extrato, $extrato);
	}
	return $vetor_extrato;
}
/*function mostraExtrato($conexao){
	
	$query="select operacao, data FROM extrato";
	$resultado= mysqli_query($conexao, $query);
	$extrato=mysqli_fetch_assoc($resultado);
	return $extrato;
}*/

function alteraCliente (Conta $Cliente, $conexao){
		$query = "update conta set saldoConta = '{$Cliente->getSaldo()}', tipoConta= '{$Cliente->getTipoConta()}',
		limiteConta = '{$Cliente->getLimite()}', nomeCliente = '{$Cliente->getNome()}'
		where numeroConta = {$Cliente->getNumero()}";
		//echo $query;
			
	return mysqli_query($conexao, $query);
	}

	function buscarCliente($conexao, $numero) {
	$query = "select * from conta where numeroConta = {$numero}";
	$resultado = mysqli_query($conexao, $query);
	$cliente_buscado = mysqli_fetch_assoc($resultado);
		$numero=$cliente_buscado['numeroConta'];
		$nome=$cliente_buscado['nomeCliente'];
		$saldo=$cliente_buscado['saldoConta'];
		$limite= $cliente_buscado['limiteConta'];
		$tipoConta= $cliente_buscado['tipoConta'];
		$usuario_id= $cliente_buscado['usuario_idUsuario'];	
		
		if($tipoConta == "corrente"){
			$Cliente= new ContaCorrente($nome, $saldo, $limite, $tipoConta,$usuario_id);
			
		}else{
			$Cliente= new ContaPoupanca($nome, $saldo, $limite, $tipoConta,$usuario_id);
				
		}
		 $Cliente->setNumero($numero);
	return $Cliente;
}

	function removeCliente ($numero, $conexao){
		$query="delete from conta where numeroConta= {$numero}";
		return mysqli_query($conexao,$query);
	}
	
?>