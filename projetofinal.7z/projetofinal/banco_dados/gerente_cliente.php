<?php
require_once("banco_dados/conexao.php");
require_once("class/Conta.php");


function insereCliente(Conta $Cliente, $conexao){
	
	$query= "insert into conta (saldoConta, tipoConta, limiteConta, nomeCliente)
			values ('{$Cliente->getSaldo()}', {$Cliente->getTipoConta()}, '{$Livro->getlimite()}',
			 {$Cliente->getNome()})";
			
	return mysqli_query($conexao, $query);
}

function listarLivros ($conexao){
	$vetor_livros= array();
	$query="select produtos.*, categorias.nome as
	categoria_nome from produtos join categorias
	on categorias.id=produtos.categoria_id";
	$resultado= mysqli_query($conexao, $query);

	while ($livro_array= mysqli_fetch_assoc($resultado)){
		/* criando um objeto Livro a cada repetição
		 do laço*/
		 $categoria= new Categorias();
		 $categoria->setNome($livro_array["categoria_nome"]);

		 $Id=$livro_array['id'];
		 $Nome=$livro_array['nome'];
		 $Preco=$livro_array['preco'];
		 $Descricao= $livro_array['descricao'];
		 $Usado=$livro_array['usado'];
		 $Categoria=$categoria;

		 $Livro= new Livro($Nome, $Preco, $Descricao, $Usado, $Categoria);
		 $Livro->setId($Id);

		 array_push($vetor_livros, $Livro);
	}
	return $vetor_livros;
}

	function alteraLivro (Livro $Livro, $conexao){
		$query = "update produtos set nome = '{$Livro->getNome()}', preco = {$Livro->getPreco()}, 
		descricao = '{$Livro->getDescricao()}', categoria_id= {$Livro->getCategoria()->getId()}, 
			usado = {$Livro->getUsado()} where id = {$Livro->getId()}";
		echo $query;
			
	return mysqli_query($conexao, $query);
	}

	function buscarLivro($conexao, $id) {

	$query = "select * from produtos where id = {$id}";
	$resultado = mysqli_query($conexao, $query);
	$livro_buscado = mysqli_fetch_assoc($resultado);

	$categoria= new Categorias();
	$categoria->setId($livro_buscado['categoria_id']);

		$Id=$livro_buscado['id'];
		$Nome=$livro_buscado['nome'];
		$Preco=$livro_buscado['preco'];
		$Descricao= $livro_buscado['descricao'];
		$Usado=$livro_buscado['usado'];
		$Categoria=$categoria;

		 $Livro= new Livro($Nome, $Preco, $Descricao, $Usado, $Categoria);
		 $Livro->setId($Id);

	return $Livro;
}

	function removeLivro ($id, $conexao){
		$query="delete from produtos where id= {$id}";
		return mysqli_query($conexao,$query);
	}
?>