<?php
require_once("banco_dados/conexao.php");

function buscarGerente($emailGerente, $senhaGerente, $conexao){
	//tratando os caracteres especiais do email
	$query= "select * from gerente where emailGerente='{$emailGerente}'
	and senhaGerente= '{$senhaGerente}'";
	$resultado= mysqli_query($conexao, $query);
	$gerente= mysqli_fetch_assoc($resultado);

	return $gerente; 
}

function buscarUsuario($email, $senha, $conexao){
	//tratando os caracteres especiais do email
	$query= "select * from usuario where email='{$email}'
	and senha= '{$senha}'";
	$resultado= mysqli_query($conexao, $query);
	$cliente= mysqli_fetch_assoc($resultado);

	return $cliente; 
}

function insereUsuario($email, $senha,$conexao){
	
	$query="insert into usuario (email,senha)
			values ('{$email}', '{$senha}')";
	return mysqli_query($conexao,$query);
}

?>