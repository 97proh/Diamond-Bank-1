<?php
require_once("cabecalho2.php");
require_once("banco_dados/gerente_cliente.php");
require_once("class/Conta.php");
require_once("class/Corrente.php");
require_once("class/Poupanca.php");



//armazenando os valores do formulário no objeto Cliente
$nome=$_POST['nomeCliente'];
$saldo=$_POST['saldoCliente'];
$limite=$_POST['limiteCliente'];
 


if($_POST['tipoConta' == "corrente"]){
	$Cliente= new ContaCorrente($numero, $nome, $saldo, $limite);
	
}else{
	$Cliente= new ContaPoupanca($numero, $nome, $saldo, $limite);
		
}

if(insereCliente($Cliente, $conexao)){ ?>

<p class="bg-success">
	O Cliente  foi cadastrado!</p>
<?php
}else{
	$msg= mysqli_error($conexao);?>
	<p class="bg-danger">
	O Cliente  não foi cadastrado: <?=$msg?></p>
<?php
}
?>