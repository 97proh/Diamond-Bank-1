<?php
/* com o abstract a class Conta não 
pode mais ser instanciada*/
class Conta{
	/*declarando os atributos da classe e 
	encapsulando como private*/
	private $numero;
	private $nome;
	private $saldo;
	private $limite;
	
	//Criando o construtor da classe
	function __construct($numero, $nome, $saldo, $limite){
		$this->numero= $numero;
		$this->nome=$nome;
		$this->saldo= $saldo;
		$this->limite= $limite;
		
	}
	
	//Criando os métodos
	public function debitar($debitar){
		// Calcula o desconto e subtrai do preco
		$this->saldo -= $this->saldo - $debitar;
		return $this->saldo;
	}
	public function creditar($creditar){
		// Calcula o desconto e subtrai do preco
		$this->saldo -= $this->saldo + $creditar;
		return $this->saldo;
	}
	public function transferir($valorTransferido){
		// Calcula o desconto e subtrai do preco
		$this->saldo -= $this->saldo - $valorTransferido;
		return $this->preco;
	}
	
	// Criando os getters e setters dos atributos
	public function getNumero(){//pega o valor do atributo
		return $this->numero;
	}
	public function setNumero($numero){//armazena o valor no atributo
		$this->numero= $numero;
	}
	public function getNome(){//pega o valor do atributo
		return $this->nome;
	}
	public function setNome($nome){//armazena o valor no atributo
		$this->nome= $nome;
	}
	public function getSaldo(){//pega o valor do atributo
		return $this->saldo;
	}
	public function setSaldo($saldo){//armazena o valor no atributo
		$this->saldo= $saldo;
	}
	public function getLimite(){//pega o valor do atributo
		return $this->limite;
	}
	public function setLimite($limite){//armazena o valor no atributo
		$this->limite= $limite;
	}
	
	//convertendo para String
	function __toString(){
		return
		"Nome: ".$this->nome.
		"</br>Preço: ".$this->preco;
	}
	//criando o destrutor
	function __destruct(){
		//echo "Destruindo o objeto Conta";
	}
}//fim da classe Conta
?>