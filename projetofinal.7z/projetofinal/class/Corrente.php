<?php

	//A classe Ebook herda os atributos e métodos da classe Livro
	class ContaCorrente extends Conta{
		


		
			public function getAtualizar(){
				$this->saldo += $this->saldo * taxa * 2;
			}

			
	
	}