<?php

	//A classe ContaCorrente herda os atributos e métodos da classe Conta
	class ContaCorrente extends Conta{
		

			//Polimorfismo
			public function atualizar($taxa=0.5){
				//retorna 5% do valor da Conta
				$this->saldo+= $this->saldo * $taxa * 2;
			}

			public function creditar($creditar){
				// Calcula o desconto e subtrai do preco
				$this->saldo -= $this->saldo + $creditar;
				return $this->saldo;
	}

			
	
	}