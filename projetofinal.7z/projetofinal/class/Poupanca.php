<?php

	//A classe ContaPoupanca herda os atributos e métodos da classe Conta
	class ContaPoupanca extends Conta{
		
		//Polimorfismo
		public function atualizar($taxa=0.5){
				//retorna 5% do valor da Conta
				$this->saldo+= $this->saldo * $taxa * 3;
			}

	
	}