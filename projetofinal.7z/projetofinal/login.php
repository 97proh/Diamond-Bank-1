<?php
require_once("banco_dados/gerente_banco.php");
require_once("logica-usuario.php");

$emailGerente= $_POST['email'];
$senhaGerente= $_POST['senha'];
$gerente=buscarGerente($emailGerente, $senhaGerente, $conexao);

if($gerente == null){ 
	$_SESSION["danger"]="Usuario ou senha inválido!";
	header("Location:gerente_login.php");
}else{ 
	$_SESSION["success"]="Usuario logado com sucesso!";
	logaUsuario($emailGerente);
	header("Location:gerente_index.php");
}
die();