<?php
require_once("banco_dados/gerente_cliente.php");
require_once("banco_dados/gerente_banco.php");
require_once("class/Conta.php");
require_once("class/Corrente.php");
require_once("class/Poupanca.php");



//Armazenando os valores do formulário de cadastro do  Cliente

$email=$_POST['emailCliente'];
$senha=$_POST['senhaCliente'];
 



if(insereUsuario($email, $senha, $conexao)){?>
<?php
	require_once("cliente_cadastro.php");
	
}else{
	$msg= mysqli_error($conexao);?>
	<p class="bg-danger">
	O Cliente <?=$email?> não foi cadastrado: <?=$msg?></p>
<?php
}
?>
