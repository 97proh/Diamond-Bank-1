
<?php
require_once("cabecalho2.php");
require_once("banco_dados/gerente_cliente.php");
require_once("class/Conta.php");
require_once("class/Corrente.php");
require_once("class/Poupanca.php");

//Criando um vetor para busca os clientes no banco
$vetor_cliente=listarCliente($conexao);
 foreach ($vetor_cliente as $Cliente) {
	$Cliente->atualizar();
	$Cliente->getSaldo();
	$Cliente=atualizarSaldo($Cliente,$conexao);
}
header("Location:gerente_index.php#listarCliente");

	


?>