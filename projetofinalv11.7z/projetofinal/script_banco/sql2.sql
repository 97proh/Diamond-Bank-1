-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema diamondbank
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema diamondbank
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `diamondbank` DEFAULT CHARACTER SET utf8 ;
USE `diamondbank` ;

-- -----------------------------------------------------
-- Table `diamondbank`.`conta`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `diamondbank`.`conta` (
  `saldoConta` INT(11) NOT NULL,
  `tipoConta` ENUM('corrente', 'poupanca') NOT NULL,
  `limiteConta` INT(11) NOT NULL,
  `nomeCliente` VARCHAR(255) NOT NULL,
  `numeroConta` INT(11) NOT NULL AUTO_INCREMENT,
  `usuario_idUsuario` INT(11) NOT NULL,
  PRIMARY KEY (`numeroConta`, `usuario_idUsuario`),
  INDEX `fk_conta_usuario1_idx` (`usuario_idUsuario` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 1002
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `diamondbank`.`usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `diamondbank`.`usuario` (
  `idUsuario` INT(11) NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(255) NOT NULL,
  `senha` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`idUsuario`))
ENGINE = InnoDB
AUTO_INCREMENT = 8
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `diamondbank`.`extrato`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `diamondbank`.`extrato` (
  `operacao` ENUM('Saque', 'Depósito', 'Transferência') NOT NULL,
  `data` DATE NOT NULL,
  `numero_id` INT(11) NOT NULL,
  `usuario_idUsuario` INT(11) NOT NULL,
  PRIMARY KEY (`usuario_idUsuario`),
  INDEX `numero_id_fk_idx` (`numero_id` ASC),
  CONSTRAINT `fk_extrato_usuario1`
    FOREIGN KEY (`usuario_idUsuario`)
    REFERENCES `diamondbank`.`usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `numero_id_fk`
    FOREIGN KEY (`numero_id`)
    REFERENCES `diamondbank`.`conta` (`numeroConta`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `diamondbank`.`gerente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `diamondbank`.`gerente` (
  `idGerente` INT(11) NOT NULL AUTO_INCREMENT,
  `emailGerente` VARCHAR(255) NOT NULL,
  `senhaGerente` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`idGerente`))
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
