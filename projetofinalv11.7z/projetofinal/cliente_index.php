<?php
   require_once("cabecalho_cliente.php");
   require_once("banco_dados/gerente_cliente.php");

    ?>
    
    <!-- NESTA SEÇÃO O CLIENTE VAI VERIFICAR O EXTRATO DA SUA CONTA-->
    <section id="extrato">
        <div class="container">
            <!-- Criando uma variável $usuario, onde vai guarda o Usuário que logou no site e com a função
            mostraUsuario vai mostrar o Usuário que está logado no site seu respectivo nome e número de conta-->
            <?php
            $usuario=mostraUsuario($conexao);?>
             <h2>Seu extrato</h2>
             <h4>Nome:<?=$usuario['nomeCliente']?></h4>
             <h4>Número da conta: <?=$usuario['numeroConta']?></h4><br><br>

             <table class="container">
                
                 <tr>                 
                        <th>Operação</th>
                        <th>Data</th>                                              
                </tr>
                <!-- Criando uma variável $extrato, onde vai guarda o extrato do Usuário que logou no site e com a função mostraExtrato vai mostrar o extrato do usuário que está logado no site.-->
                <?php
                $vetor_extrato=mostraExtrato($conexao);
                foreach ($vetor_extrato as $extrato) {
                ?>
                    
                <tr>
                        <td><?=$extrato['operacao']?></td>
                        <td><?=$extrato['data']?></td>

                </tr>

                   <?php
                }
                    ?>     
             </table>    

            
    </section>

    <!-- NESTA SEÇÃO O CLIENTE VAI PODE SACAR DA SUA CONTA-->
    <center><section id="saque">
        <div class="cliente-container">          
            
            <form action="cliente_sacar.php" method="POST">
                <h2>Digite o valor a ser sacado:</h2>                
                 <input  type="hidden" name="numero" value="<?=$usuario['numeroConta']?>"><br><br>  
                <input class="form-control" type="number" name="sacar"><br><br>                
                <button class="btn btn-primary" type="submit">Sacar</button>
            </form>
            
        </div>
    </section></center>

    <!-- NESTA SEÇÃO O CLIENTE VAI PODE DEPOSITAR NA SUA CONTA-->
   <center><section id="deposito">
        <div class="cliente-container">
           
            <form action="cliente_depositar.php" method="POST">
                 <h2>Digite o valor a ser depositado:</h2>
                <input  type="hidden" name="numero" value="<?=$usuario['numeroConta']?>"><br><br>
                <input name="depositar" type="number" class="form-control"><br><br>                       
             <button class="btn btn-primary" type="submit">Depositar</button>
            </form>
        </div>
    </section></center>

    <!-- NESTA SEÇÃO O CLIENTE VAI PODE FAZER TRANFÊRENCIA-->
    <center><section id="transferencia">
        <div class="cliente-container">        
            
            <form action="cliente_transfere.php" method="POST">
                <input  type="hidden" name="numero" value="<?=$usuario['numeroConta']?>"><br><br>
                <h2>Informe o número da conta destino:</h2>
                <input name="contaDestino" type="text"><br><br>  
                <h2>Informe o valor a ser tranferido para conta destino:</h2>  
                <input name="transferir" type="number"><br><br> 
             <button class="btn btn-primary" type="submit">Transferir</button>
            </form>
        </div>
    </section></center>


    
<?php
require_once("rodape.php"); 
?>

   