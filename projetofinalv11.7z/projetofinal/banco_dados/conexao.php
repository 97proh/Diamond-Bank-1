<?php
# $conexao = mysqli_connect("mysql.hostinger.com.br", "u548680052_loja", "lojaloja", "u548680052_loja");

$conexao = mysqli_connect("localhost", "root", "senai@2016", "diamondbank");

