<?php
require_once("banco_dados/gerente_banco.php");
require_once("logica-usuario.php");

//Criando váriaves para guarda dados do formulário de login
$email= $_POST['email'];
$senha= $_POST['senha'];

//Chamando a função buscarUsuario e salvando na váriavel $cliente  para guarda o usuario 
//buscado pela função
$cliente=buscarUsuario($email, $senha, $conexao);


if($cliente == null){ 
	$_SESSION["danger"]="Usuario ou senha inválido!";
	header("Location:cliente_login.php");
}else{ 
	$_SESSION["success"]="Usuario logado com sucesso!";
	logaUsuario($email);
	header("Location:cliente_index.php");
}
die();