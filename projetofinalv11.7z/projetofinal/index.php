<?php
require_once("cabecalho.php");
?>
   
    <header>
        <div class="container">
            <div class="intro-text">
                <div class="intro-lead-in">Bem vindo!</div>
                <div class="intro-heading">queremos você como cliente</div>
                <a href="#saibamais" class="page-scroll btn btn-xl">Saiba mais</a>
            </div>
        </div>
    </header>
   
   

    
    <section id="saibamais">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Sobre nós</h2>
                    <h3 class="section-subheading text-muted">Buscando o melhor para você.</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <ul class="timeline">
                        <li>
                            <div class="timeline-image">
                                <img class="img-circle img-responsive" src="img/sobre/1.jpg" alt="">
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">                                    
                                    <h4 class="subheading">Foco comercial</h4>
                                </div>
                                <div class="timeline-body">
                                    <p class="text-muted">Oferecemos a nossos clientes ampla variedade de produtos e serviços financeiros por meio da maior rede de agências entre todos os bancos internacionais.</p>
                                </div>
                            </div>
                        </li>
                        <li class="timeline-inverted">
                            <div class="timeline-image">
                                <img class="img-circle img-responsive" src="img/sobre/2.jpg" alt="">
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">                                    
                                    <h4 class="subheading">Foco na solidez</h4>
                                </div>
                                <div class="timeline-body">
                                    <p class="text-muted">É um dos bancos mais sólidos e solventes do mundo. Além disso, mantém uma posição de liquidez confortável, baseada no financiamento por meio de depósitos dos clientes e emissões de títulos de dívidas a médio e longo prazo.</p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="timeline-image">
                                <img class="img-circle img-responsive" src="img/sobre/3.jpg" alt="">
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">                                    
                                    <h4 class="subheading">Nossa marca</h4>
                                </div>
                                <div class="timeline-body">
                                    <p class="text-muted">Nossa marca é uma das mais valorizadas do setor financeiro, de acordo com consultorias especializadas, e representa os valores que tornam o Grupo único: dinamismo, força, inovação, liderança, enfoque comercial e ética profissional.</p>
                                </div>
                            </div>
                        </li>                  
                        
                    </ul>
                </div>
            </div>
        </div>
    </section>

    

    
    <section id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Atendimento</h2>
                    <h3 class="section-subheading text-muted">envie a sua mensagem</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <form name="sentMessage" id="contactForm" novalidate>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Seu nome *" id="name" required data-validation-required-message="Porfavor informe seu nome.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" placeholder="Seu email *" id="email" required data-validation-required-message="Porfavor informe seu email.">
                                    <p class="help-block text-danger"></p>
                                </div>
                                <div class="form-group">
                                    <input type="tel" class="form-control" placeholder="Seu telefone *" id="phone" required data-validation-required-message="Porfavor informe seu telefone.">
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <textarea class="form-control" placeholder="Sua Mensagem *" id="message" required data-validation-required-message="Porfavor informe sua me."></textarea>
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-lg-12 text-center">
                                <div id="success"></div>
                                <button type="submit" class="btn btn-xl">Envie a mensagem</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    
<?php include("rodape.php"); ?>