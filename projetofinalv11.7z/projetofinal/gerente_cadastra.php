<?php
require_once("cabecalho2.php");
require_once("banco_dados/gerente_cliente.php");
require_once("banco_dados/gerente_banco.php");
require_once("class/Conta.php");
require_once("class/Corrente.php");
require_once("class/Poupanca.php");



//Armazenando os valores do formulário de cadastro do  Cliente

$nome=$_POST['nomeCliente'];
$saldo=$_POST['saldoCliente'];
$limite=$_POST['limiteCliente'];
$tipoConta= $_POST['tipoConta'];
$usuario_id= $_POST['cliente_id'];

if($tipoConta == "corrente"){
	$Cliente= new ContaCorrente($nome, $saldo, $limite, $tipoConta,$usuario_id);
	
}else{
	$Cliente= new ContaPoupanca($nome, $saldo, $limite, $tipoConta,$usuario_id);
		
}



if($limite >= $saldo and insereCliente($Cliente, $conexao)){ ?>

<div class="container">
	<h2> Cliente <?=$Cliente?> foi cadastrado!</h2><br><br>
	<a href="gerente_index.php#cadastrarCliente" class="btn btn-primary" >Cadastrar novo cliente</a>
	<a href="gerente_index.php#listarCliente" class="btn btn-primary" >Ir para lista de cliente</a>
	<a href="gerente_index.php" class="btn btn-primary" >Página Inicial</a>
</div>
<?php
}else{
	$msg= mysqli_error($conexao);?>
	<p class="bg-danger">
	O Cliente <?=$email?> não foi cadastrado: <?=$msg?></p>
<?php
}
?>