<?php
require_once("cabecalho2.php");
require_once("class/Conta.php");
require_once("class/Extrato.php");
require_once("banco_dados/gerente_cliente.php");
require_once("banco_dados/gerente_banco.php");

//Criando váriaves para guarda dados do formulário do deposito de dinheiro
$numeroConta=$_POST['numero'];
$valor=$_POST['depositar'];
$data=  date("Y-m-d");

//Chamando a função buscarCliente e salvando na váriavel $Cliente o cliente no qual
//será depositado o dinheiro
$Cliente= buscarCliente($conexao, $numeroConta);

//Executando o método depositar que deposita o valor na conta
$Cliente->depositar($valor);

if(atualizarSaldo($Cliente,$conexao) and insereDeposito($data, $numeroConta, $conexao)){ ?>

<div class="container">
	<h2> Deposito realizado com sucesso !</h2>
	<h3>Novo saldo da conta: <?=$Cliente->getSaldo()?> </h3>
	<a href="cliente_index.php#deposito" class="btn btn-primary" >Depositar novamente</a>
	<a href="cliente_index.php#extrato" class="btn btn-primary" >Veja seu extrato</a>
	<a href="cliente_index.php" class="btn btn-primary" >Página Inicial</a>
</div>

<?php
}else{
	$msg= mysqli_error($conexao);?>
	<p class="bg-danger">
	Erro no deposito <?=$msg?></p>
<?php
}
require_once("rodape.php");
?>
