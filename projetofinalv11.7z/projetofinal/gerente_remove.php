<?php

require_once("banco_dados/gerente_cliente.php");



$numero= $_POST['numero'];

if(removeCliente($numero, $conexao)){
	?>
<?php
header("Location:gerente_index.php#listarCliente");
?>
<?php
}else{
	$msg= mysqli_error($conexao);?>
	<p class="bg-danger">Cliente não foi removido: <?=$msg?></p>
<?php
}
?>