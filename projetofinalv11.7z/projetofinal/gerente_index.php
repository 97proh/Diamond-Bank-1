<?php
require_once("banco_dados/gerente_cliente.php");
require_once("banco_dados/gerente_banco.php");
require_once("cabecalho_gerente.php");


?>

   

    <!-- NESTA SEÇÃO O GERENTE VAI CADASTRAR OS CLIENTES-->
    <section id="cadastrarCliente">
        <div class="container">
           
            <form action="gerente_cadastra-login.php" method="post">
            
            <h1>Cadastro de Cliente</h1>

                <table class="table"> 
                   <tr>
                        <td>Email do Cliente</td>
                        <td><input class="form-control" type="email" name="emailCliente" value=""></td>
                    </tr>   

                     <tr>
                        <td>Senha do Cliente</td>
                        <td><input class="form-control" type="password" name="senhaCliente" value=""></td>
                    </tr>   
                     <tr>
                        <td><button class="btn btn-primary" type="submit">Próximo</button></td>
                        
                    </tr>
                </form>
                </table>
            </div>
                </section>

<section id="listarCliente">
        <div class="container">
           <h2>Lista de Clientes</h2>
                     
          
            <table class="table">
                <tr>
                        <th>Número da Conta</th>
                        <th>Nome</th>
                        <th>Saldo</th>
                        <th>Limite</th>
                        <th>Tipo de Conta</th>
                        <th>Alterar</th>
                        <th>Excluir</th>
                </tr>
                <?php
                $vetor_cliente=listarCliente($conexao);
                foreach ($vetor_cliente as $Cliente) {
                ?>
                    
                <tr>
                        <td><?=$Cliente->getNumero()?></td>
                        <td><?=$Cliente->getNome()?></td>
                        <td><?=$Cliente->getSaldo()?></td>
                        <td><?=$Cliente->getLimite()?></td>
                        <td><?=$Cliente->getTipoConta()?></td>
                        
                        <td>
                            <form action="gerente_formularioAltera.php" method="get">
                                <input type="hidden" name="numero" value="<?=$Cliente->getNumero()?>">
                                <button class="btn btn-primary">Alterar</button>
                            </form>
                        </td>
                        <td>
                            <form action="gerente_remove.php" method="post">
                                <input type="hidden" name="numero" value="<?=$Cliente->getNumero()?>">
                                <button class="btn btn-primary">Remover</button>
                            </form>
                        </td>
                </tr>   
            <?php
                }
            ?>
            </table>
             <form action="atualiza_saldo.php" method="get">
                 <input type="hidden" name="tipoConta" value="<?=$Cliente->getTipoConta()?>">
                 <button class="btn btn-primary">Atualizar</button>
            </form>
        </div>
    </section>


<?php
require_once("rodape.php"); 
?>


   