<?php
   require_once("cabecalho_cliente.php");
   require_once("banco_dados/gerente_cliente.php");

    ?>
    
    <!-- NESTA SEÇÃO O CLIENTE VAI VERIFICAR O EXTRATO DA SUA CONTA-->
    <section id="extrato">
        <div class="container">
            <?php
            $usuario=mostraUsuario($conexao);?>
             <h2>Seu extrato</h2>
             <h4>Nome:<?=$usuario['nomeCliente']?></h4>
             <h4>Número da conta: <?=$usuario['numeroConta']?></h4><br><br>

             <table class="container">
                 <tr>
                        <th>Operação</th>
                        <th>Data</th>                        
                </tr>
                <?php
                     $extrato=mostraExtrato($conexao);?>
                    
                <tr>
                        <td><?=$extrato['operacao']?></td>
                        <td><?=$extrato['data']?></td>
                </tr>

                        
             </table>    

            
    </section>

    <!-- NESTA SEÇÃO O CLIENTE VAI PODE SACAR DA SUA CONTA-->
    <center><section id="saque">
        <div class="container">          
            
            <form action="cliente_sacar.php" method="POST">
                <h2>Digite o valor a ser sacado:</h2>
                 <input  type="hidden" name="numero" value="<?=$usuario['numeroConta']?>"><br><br>  
                <input class="form-control" type="number" name="sacar"><br><br>                
                <button class="btn btn-primary" type="submit">Sacar</button>
            </form>
            
        </div>
    </section></center>

    <!-- NESTA SEÇÃO O CLIENTE VAI PODE DEPOSITAR NA SUA CONTA-->
   <center><section id="deposito">
        <div class="container">
           <h2>Digite o valor a ser depositado:</h2>
            <form action="#.php" method="get">
                <input  type="hidden" name="numero" value="<?=$usuario['numeroConta']?>"><br><br>
                <input name="depositar" type="number" class="form-control"><br><br> 
             <h2>Digite o numero da conta</h2>    
             <input name="numero" type="number" class="form-control"><br><br>           
             <button class="btn btn-primary" type="submit">Depositar</button>
            </form>
        </div>
    </section></center>

    <!-- NESTA SEÇÃO O CLIENTE VAI PODE FAZER TRANFÊRENCIA-->
    <center><section id="transferencia">
        <div class="container">        
            
            <form action="#.php" method="get">
                <h2>Informe o número da conta:</h2>
                <input name="numeroConta" type="text"><br><br>  
                <h2>Informe o valor a ser tranferido:</h2>  
                <input name="transferir" type="number"><br><br> 
             <button class="btn btn-primary" type="submit">Transferir</button>
            </form>
        </div>
    </section></center>


    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <span class="copyright">Todos os direitos reservados &copy; Diamond Bank 2017</span>
                </div>
                <div class="col-md-4">
                    <ul class="list-inline social-buttons">
                        <li><a href="https://twitter.com/DiammondBank" target="_blank"><i class="fa fa-twitter"></i></a>
                        </li>
                        <li><a href="https://www.facebook.com/diammondbank/" target="_blank"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li><a href="https://www.linkedin.com/in/diamond-bank-1a0a22140/" target="_blank"><i class="fa fa-linkedin"></i></a>
                        </li>
                    </ul>
                </div>
                
            </div>
        </div>
    </footer>

       

    
    <script src="jquery/jquery.js"></script>

    
    <script src="bootstrap/js/bootstrap.js"></script>

   
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js" integrity="sha384-mE6eXfrb8jxl0rzJDBRanYqgBxtJ6Unn4/1F7q4xRRyIw7Vdg9jP4ycT7x1iVsgb" crossorigin="anonymous"></script>

    
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    
    <script src="js/agency.js"></script>

</body>

</html>
