<?php
class Extrato{
	//declarando os atributos e encapsular os dados
	private $operacao;
	private $data;
	private $numero;

	//Criando o construtor da classe
	function __construct($operacao, $data, $numero){
		
		$this->operacao= $operacao;
		$this->data= $data;
		$this->numero= $numero;
		
	}
	
	//criando os getters e setters
	
	public function getOperacao(){//pega o valor do atributo
		return $this->operacao;
	}
	public function setOperacao($operacao){//armazena o valor no atributo
		$this->operacao= $operacao;
	}
	public function getData(){//pega o valor do atributo
		return $this->data;
	}
	public function setData($data){//armazena o valor no atributo
		$this->data= $data;
	}
	public function getNumero(){//pega o valor do atributo
		return $this->numero;
	}
	public function setNumero($numero){//armazena o valor no atributo
		$this->numero= $numero;
	}
		
	function verSaldo(){
             return $this->saldo;
  }
}
?>