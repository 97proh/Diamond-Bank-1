<?php
require_once("cabecalho2.php");
require_once("banco_dados/gerente_cliente.php");
require_once("class/Conta.php");
require_once("class/Corrente.php");
require_once("class/Poupanca.php");

$numero=$_POST['numeroConta'];
$nome=$_POST['nomeCliente'];
$saldo=$_POST['saldoConta'];
$limite=$_POST['limiteConta'];
$tipoConta=$_POST['tipoConta'];


//Criando o objeto Cliente através do seu construtor
$Cliente= new Conta($nome, $saldo, $limite, $tipoConta);
$Cliente->setNumero($numero);//atribuindo o valor do numero


if($limite > $saldo and alteraCliente($Cliente, $conexao)){?>
<div class="container">
	<h2>O Cliente <?=$Cliente->getNome()?> foi alterado!</h2>
	<a href="gerente_index.php#listarCliente" class="btn btn-primary" >Alterar outro cliente</a>
	<a href="gerente_index.php" class="btn btn-primary" >Página Inicial</a>
</div>
<?php
}else{?>
	<div class="container">	
	<h2>O Cliente  não foi alterado, saldo maior que o limite.</h2>
	<a href="gerente_index.php#listarCliente" class="btn btn-primary" >Altere novamente</a>
	</div>
<?php
}
include("rodape.php");
?>