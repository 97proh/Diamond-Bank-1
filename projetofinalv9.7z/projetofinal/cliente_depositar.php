<?php
require_once("class/Conta.php");
require_once("class/Extrato.php");
require_once("banco_dados/gerente_cliente.php");
require_once("banco_dados/gerente_banco.php");

$numeroConta=$_POST['numero'];
$SaldoContaDeposito=$_POST['depositar'];

$conta=buscarConta($numeroConta, $conexao);

$saldo = $conta['saldoConta'] + $SaldoContaDeposito;

if(atualizarSaldo($numeroConta, $saldo, $conexao)){
	?>
	<p class="container">O depósito de valor <?=$SaldoContaDeposito?> foi efetuado</p>
	<?php

	//$data= dataDeposito($conexao);

}else{
	$msg= mysqli_error($conexao);
	?>
		<p class="container">O seu depósito não foi efetuado</p>
	<?php
}

$valor=$_POST['sacar'];
$data=  date("Y-m-d");


//Criando o objeto Cliente através do seu construtor
$Cliente= buscarCliente($conexao, $numeroConta);
//$Cliente->setNumero($numero);

$Cliente->depositar($valor);
atualizarSaldo($Cliente,$conexao);

	echo $Cliente->getSaldo();


//if(insereSaque($Cliente, $conexao)){ 
?>
