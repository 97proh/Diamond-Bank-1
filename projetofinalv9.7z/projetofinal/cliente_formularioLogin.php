<?php
require_once ("cabecalho2.php");
?>



	<div class="login-container">
		<form action="cliente_login.php" method="post">
			<a id="login-form-logo" href="index.php"><img src="img/logo.png" alt="Logar no diamond bank"></a>

			<div class="login-form-row form-group">
		      <div id="login-email-logo">
		        <i class="glyphicon glyphicon-envelope"></i>
		        <div class="arrow-right"></div>
		      </div>
		      <input placeholder="Email do cliente" tabindex="1" autofocus="autofocus" class="form-control"  name="email"  type="email">
		    </div>

		    <div class="login-form-row form-group">
		      <div id="login-password-logo">
		        <i class="glyphicon glyphicon-lock"></i>
		        <div class="arrow-right"></div>
		      </div>
		      <input tabindex="2" placeholder="Senha" class="form-control" name="senha" type="password">
		    </div>

		    <input name="commit" value="Login" class="button button-cta" data-disable-with="Login" type="submit">
			

		</form>
	</div>


	
<?php

require_once("rodape.php");
?>
