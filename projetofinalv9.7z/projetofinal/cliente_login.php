<?php
require_once("banco_dados/gerente_banco.php");
require_once("logica-usuario.php");

$email= $_POST['email'];
$senha= $_POST['senha'];
$cliente=buscarUsuario($email, $senha, $conexao);

if($cliente == null){ 
	$_SESSION["danger"]="Usuario ou senha inválido!";
	header("Location:cliente_login.php");
}else{ 
	$_SESSION["success"]="Usuario logado com sucesso!";
	logaUsuario($email);
	header("Location:cliente_index.php");
}
die();