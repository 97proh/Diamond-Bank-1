<?php
require_once("class/Conta.php");
require_once("class/Extrato.php");
require_once("banco_dados/gerente_cliente.php");
require_once("banco_dados/gerente_banco.php");

$numeroConta=$_POST['numero'];
$valor=$_POST['sacar'];
$data=  date("Y-m-d");


//Criando o objeto Cliente através do seu construtor
$Cliente= buscarCliente($conexao, $numeroConta);
//$Cliente->setNumero($numero);

$Cliente->sacar($valor);
atualizarSaldo($Cliente,$conexao);

	echo $Cliente->getSaldo();


//if(insereSaque($Cliente, $conexao)){ 
?>
